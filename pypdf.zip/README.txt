Bundled so ferc_text.py can read PDFs without a pip install.
pypdf 6.19.0 (BSD-3-Clause) - https://pypi.org/project/pypdf/
typing_extensions (PSF License, used only on Python < 3.11)
License texts are in licenses/.
